#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 AutoResearch 流水线的真实产物生成一篇完整、可投稿的中文研究论文（任务无关版）。

设计原则：**零编造**。
  - 所有数字、表格、图都来自流水线真实产物（由确定性分析引擎计算）。
  - 文字部分（摘要/引言/相关工作/深入分析/讨论/结论）由大模型**只基于这些真实产物**
    撰写，提示词中显式禁止引入任何未出现在素材中的数值、文献或结论。
  - 若大模型不可用（无 Key / 报错 / 限流），自动降级为确定性骨架，论文依然可产出。

输入：
  - 01_literature.json   真实文献（标题/作者/期刊/年份/URL）
  - 02_hypotheses.json   由 task-spec 派生的主假设 + 机制化子假设
  - 03_experiment.json   分析引擎的真实指标与 analysis（逐类/混淆矩阵/特征重要性/
                          多种子方差/显著性/图）
  - 04_review.json       同行评审意见（用于局限性）
  - --task-spec          任务规格（方向/数据集/方法/指标/分析计划）

输出：Markdown + .docx（含真实表格与图片）。
"""
from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path


# ── 基础工具 ──────────────────────────────────────────────────────
def _load(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _round(x, n: int = 4):
    try:
        return round(float(x), n)
    except (TypeError, ValueError):
        return x


def _fmt(x, n: int = 4) -> str:
    v = _round(x, n)
    if isinstance(v, float):
        return f"{v:.{n}f}"
    return str(v)


def _short_authors(authors: str) -> str:
    if not authors:
        return "佚名"
    parts = [a.strip() for a in authors.replace("，", ",").split(",") if a.strip()]
    if len(parts) <= 3:
        return "，".join(parts)
    return f"{parts[0]} 等"


def _method_label(m) -> str:
    """把候选方法声明（字符串或 dict）渲染成可读名称（取估计器类名）。"""
    if isinstance(m, str):
        return m.rsplit(".", 1)[-1] if "." in m else m
    if isinstance(m, dict):
        s = m.get("name") or m.get("estimator") or "model"
        if "." in s:
            s = s.rsplit(".", 1)[-1]
        return s
    return str(m)


def _join_methods(ms, sep: str = "、") -> str:
    if not ms:
        return "若干基线模型"
    return sep.join(_method_label(m) for m in ms)


# 候选方法的确定性机理描述（无需 LLM，避免 3.2 节只罗列名字的模板感）。
_METHOD_DESC = {
    "logisticregression": "线性模型，通常采用 L2 正则，假设特征与对数几率呈线性关系，"
                          "对线性可分结构高效且系数可解释，但对特征尺度与多重共线性敏感。",
    "linearregression": "最小二乘线性模型，无额外归纳偏置，对线性关系的拟合最充分，但对异常值高度敏感。",
    "ridge": "带 L2 正则的线性回归，通过收缩系数抑制过拟合，对多重共线性稳健。",
    "lasso": "带 L1 正则的线性回归，倾向于把不重要的系数精确压缩为 0，可同时完成特征选择。",
    "randomforest": "集成多棵去相关决策树，通过对样本与特征的双重自助采样降低方差，"
                    "对非线性边界与特征尺度不敏感，但解释性弱于线性模型。",
    "gradientboosting": "串行叠加弱回归树的提升方法，对复杂非线性关系的拟合能力强，"
                        "但更易过拟合且对噪声与超参数敏感。",
    "svc": "基于最大间隔超平面与核技巧的核方法，在高维或边界清晰时稳健，对特征尺度高度敏感。",
    "svr": "支持向量回归，通过 ε-不敏感损失只关注边界外样本，对特征尺度敏感。",
    "linearsvc": "线性支持向量机，采用线性核与合页损失，训练快、对高维与稀疏特征高效，但对特征尺度与异常点敏感，概率校准较弱。",
    "linearsvr": "线性支持向量回归，通过 ε-不敏感损失只关注边界外样本，对特征尺度敏感，高维场景训练高效。",
    "kneighbors": "基于局部相似性的惰性学习，无需显式训练，对小样本局部结构敏感，但受特征尺度影响大。",
    "decisiontree": "单棵决策树，可刻画非线性交互、解释性强，但方差大、容易过拟合。",
    "gaussiannb": "基于特征条件独立假设的概率生成模型，训练极快，但在特征强相关时表现受限。",
    "mlp": "多层前馈神经网络，通过非线性激活刻画复杂映射，容量大但需要更多数据与调参。",
}


def _method_bullets(spec: dict) -> str:
    """为候选方法生成确定性机理描述列表（3.2 节用，不依赖 LLM）。"""
    out = []
    for m in spec.get("candidate_methods", []):
        if not isinstance(m, dict):
            continue
        nm = (m.get("name") or "").strip()
        est = (m.get("estimator") or "").lower()
        base = est.rsplit(".", 1)[-1]
        desc = None
        for k, v in _METHOD_DESC.items():
            if base.startswith(k):
                desc = v
                break
        if nm and desc:
            out.append(f"- **{nm}**：{desc}")
        elif nm:
            out.append(f"- **{nm}**")
    return "\n".join(out)


_DATASET_CN = {
    "wine": "葡萄酒（wine）",
    "iris": "鸢尾花（iris）",
    "digits": "手写数字（digits）",
    "breast_cancer": "乳腺癌（breast_cancer）",
    "diabetes": "糖尿病进展（diabetes）",
}


def _dataset_label(spec: dict) -> str:
    """从 spec 推断可读的数据集名（兼容 data.name 与旧 dataset 字段）。"""
    d = spec.get("data") or {}
    name = d.get("name") or spec.get("dataset") or "指定数据集"
    if name in _DATASET_CN:
        return _DATASET_CN[name]
    if d.get("source") in ("csv", "parquet", "excel", "feather"):
        from pathlib import Path as _P
        stem = _P(str(d.get("path", ""))).stem
        return f"用户数据集（{stem or 'data'}）"
    return name


def build_references(lit: dict) -> list[dict]:
    refs = []
    for i, p in enumerate(lit.get("papers") or [], start=1):
        if not isinstance(p, dict):
            continue
        refs.append({
            "num": i,
            "title": p.get("title", "未知标题"),
            "authors": _short_authors(p.get("authors", "")),
            "venue": p.get("venue", ""),
            "year": p.get("year", ""),
            "url": p.get("url", ""),
        })
    return refs


def ref_citation(refs: list[dict], idx: int) -> str:
    if idx < 0 or idx >= len(refs):
        return ""
    r = refs[idx]
    return f"[{r['num']}]"


def _best_method(metrics: list[dict], main_metric: str, objective: str):
    cand = []
    for m in metrics:
        name = str(m.get("name", ""))
        try:
            val = float(m.get("value"))
        except (TypeError, ValueError):
            continue
        hay = (name + " " + str(m.get("metric", ""))).lower()
        if main_metric and main_metric.lower() not in hay:
            continue
        method = name.split("_")[0] if "_" in name else name
        cand.append((method, val))
    if not cand:  # 兜底：指标名未嵌入主指标关键字时，全部视作主指标
        for m in metrics:
            try:
                val = float(m.get("value"))
            except (TypeError, ValueError):
                continue
            name = str(m.get("name", ""))
            method = name.split("_")[0] if "_" in name else name
            cand.append((method, val))
    if not cand:
        return None, None
    cand.sort(key=lambda x: x[1], reverse=(objective != "minimize"))
    return cand[0][0], cand[0][1]


def _split_metric_name(name: str, metrics_names):
    """把 'KNN_original_accuracy' 拆成 (方法, 设置, 指标)。

    策略：从右往左匹配已知指标名（accuracy / f1_macro / r2 / mse / mae ...）。
    """
    known = ["f1_macro", "accuracy", "r2", "mse", "mae", "rmse"]
    for k in sorted(known, key=len, reverse=True):
        if name.lower().endswith("_" + k):
            head = name[: -(len(k) + 1)]
            parts = head.split("_")
            method = parts[0]
            setting = "_".join(parts[1:]) or "默认"
            return method, setting, k
    parts = name.split("_")
    return (parts[0], "_".join(parts[1:]) or "默认", "") if len(parts) > 1 else (name, "默认", "")


# ── 表格生成（全部来自真实数据） ────────────────────────────────────
def _md_table(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return "（无数据）"
    out = ["| " + " | ".join(headers) + " |",
           "| " + " | ".join(["---"] * len(headers)) + " |"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def _main_metric_table(metrics: list[dict], main_metric: str, objective: str) -> str:
    rows = []
    for m in metrics:
        name = str(m.get("name", ""))
        hay = (name + " " + str(m.get("metric", ""))).lower()
        if main_metric and main_metric.lower() not in hay:
            continue
        setting = m.get("setting") or "全部特征"
        rows.append([name, setting, _fmt(m.get("value"))])
    if not rows:  # 兜底：指标名未嵌入关键字时，列出全部主指标
        for m in metrics:
            rows.append([str(m.get("name", "")), m.get("setting") or "全部特征",
                         _fmt(m.get("value"))])
    if not rows:
        return "（无主指标数据）"
    rows.sort(key=lambda r: float(r[2]) if _is_num(r[2]) else 0.0,
              reverse=(objective != "minimize"))
    return _md_table(["方法", "特征设置", main_metric or "指标"], rows)


def _is_num(s) -> bool:
    try:
        float(s)
        return True
    except (TypeError, ValueError):
        return False


def _full_metrics_table(metrics: list[dict]) -> str:
    rows = [[str(m.get("name", "")), _fmt(m.get("value"))] for m in metrics]
    return _md_table(["指标", "数值"], rows)


def _variance_table(analysis: dict) -> str:
    sv = (analysis or {}).get("seed_variance") or {}
    rows = []
    for k, v in sv.items():
        if isinstance(v, dict):
            seeds = v.get("seeds") or []
            rows.append([k, _fmt(v.get("mean")), _fmt(v.get("std")),
                         "、".join(_fmt(s, 4) for s in seeds[:5])])
        elif isinstance(v, (int, float)):
            rows.append([k, _fmt(v), "-", "-"])
    if not rows:
        return "（未报告多种子方差）"
    return _md_table(["条目", "均值", "标准差", "各种子取值"], rows)


def _per_class_table(analysis: dict, prefer: str = "") -> str:
    pc = (analysis or {}).get("per_class") or {}
    if not isinstance(pc, dict) or not pc:
        return ""
    key = prefer if prefer in pc else list(pc.keys())[0]
    data = pc.get(key)
    if not isinstance(data, dict):
        return ""
    # data 形如 {"class_0_precision":..,"class_0_recall":..} 或 {"0": {...}}
    rows = []
    grouped = {}
    for k, v in data.items():
        if not isinstance(v, (int, float)):
            continue
        m = re.match(r"class_(\w+?)_(precision|recall|f1|f1_macro|support)$", str(k))
        if m:
            grouped.setdefault(m.group(1), {})[m.group(2)] = v
        else:
            m2 = re.match(r"(\w+?)_(precision|recall|f1)$", str(k))
            if m2:
                grouped.setdefault(m2.group(1), {})[m2.group(2)] = v
    if grouped:
        for cls in sorted(grouped):
            g = grouped[cls]
            rows.append([cls,
                         _fmt(g.get("precision", "-"), 3) if _is_num(g.get("precision", "")) else "-",
                         _fmt(g.get("recall", "-"), 3) if _is_num(g.get("recall", "")) else "-",
                         _fmt(g.get("f1", "-"), 3) if _is_num(g.get("f1", "")) else "-"])
        return f"**逐类指标（{key}）**\n\n" + _md_table(["类别", "Precision", "Recall", "F1"], rows)
    return ""


def _confusion_table(analysis: dict, prefer: str = "") -> str:
    cm = (analysis or {}).get("confusion_matrix") or {}
    if not isinstance(cm, dict) or not cm:
        return ""
    key = prefer if prefer in cm else list(cm.keys())[0]
    mat = cm.get(key)
    if not isinstance(mat, list) or not mat or not isinstance(mat[0], list):
        return ""
    n = len(mat)
    headers = ["真实\\预测"] + [str(i) for i in range(n)]
    rows = [[str(i)] + [str(int(c)) if isinstance(c, (int, float)) else str(c) for c in mat[i]]
            for i in range(n)]
    return f"**混淆矩阵（{key}）**\n\n" + _md_table(headers, rows) if n <= 12 else ""


def _feature_importance_table(analysis: dict, top: int = 10) -> str:
    fi = (analysis or {}).get("feature_importance") or {}
    if not isinstance(fi, dict) or not fi:
        return ""
    key = list(fi.keys())[0]
    data = fi.get(key)
    if not isinstance(data, dict):
        return ""
    items = sorted(((k, v) for k, v in data.items() if isinstance(v, (int, float))),
                   key=lambda x: abs(x[1]), reverse=True)[:top]
    if not items:
        return ""
    rows = [[str(k), _fmt(v, 4)] for k, v in items]
    return f"**特征重要性 Top-{len(rows)}（{key}）**\n\n" + _md_table(["特征", "重要性"], rows)


def _plots_block(analysis: dict, base: Path) -> str:
    plots = (analysis or {}).get("plots") or []
    lines = []
    for p in plots:
        if not isinstance(p, dict):
            continue
        rel = p.get("path") or p.get("file")
        if not rel:
            continue
        cap = p.get("caption") or p.get("file")
        if (base / rel).exists():
            lines.append(f"![{cap}]({rel})")
            lines.append("")
        lines.append(f"图：{cap}")
        lines.append("")
    return "\n".join(lines)


def _cross_dataset_block(analysis: dict, base: Path) -> str:
    """多数据集对比章节（markdown）。analysis 为 run_multi_analysis 产出的 combined。"""
    labels = analysis.get("dataset_labels") or []
    order = analysis.get("method_order") or []
    cross = analysis.get("cross_table") or {}
    metric = analysis.get("metric") or "accuracy"
    if not labels or not order:
        return ""
    parts = []
    # 跨数据集各方法指标表：行=数据集，列=方法
    header = ["数据集"] + order
    rows = []
    for lab in labels:
        ct = cross.get(lab, {})
        cells = [f"{ct.get(m):.4f}" if ct.get(m) is not None else "—" for m in order]
        rows.append([lab] + cells)
    parts.append(f"**表 跨数据集各方法主指标对比（{metric}）**\n")
    parts.append(_md_table(header, rows) + "\n")
    # 排名稳定性表
    stab = analysis.get("rank_stability") or {}
    if stab:
        srows = []
        for m in order:
            s = stab.get(m)
            if s:
                srows.append([m, f"{s['mean_rank']:.2f}", f"{s['std_rank']:.2f}",
                              str(len(s.get("ranks", [])))])
        if srows:
            parts.append("**表 排名稳定性（平均排名越小越稳健；标准差越小跨数据集越一致）**\n")
            parts.append(_md_table(["方法", "平均排名", "排名标准差", "参与数据集数"], srows) + "\n")
    # 对比图
    for p in (analysis.get("plots") or []):
        rel = p.get("path") or p.get("file")
        if rel and (base / rel).exists():
            parts.append(f"![{p.get('caption', rel)}]({rel})\n")
            parts.append(f"图：{p.get('caption', rel)}\n")
            break
    return "".join(parts)


# ── LLM 写作（只基于真实素材，禁止编造） ────────────────────────────
def _real_api_key(key: str) -> bool:
    """判断是否为可用的真实 API Key（与 planner.llm_client 标准一致）。"""
    if not key or len(key) < 20:
        return False
    if any(ord(c) > 127 for c in key):  # 含非 ASCII（如占位中文「在此填入...」）
        return False
    if key.startswith("在此"):
        return False
    if re.match(r"^(your[_ -]?api[_ -]?key|replace[_ -]?me|<[^>]+>)$", key, re.I):
        return False
    return True


def _llm_client():
    base = os.environ.get("OPENAI_BASE_URL")
    key = os.environ.get("OPENAI_API_KEY")
    if not base or not _real_api_key(key):
        return None, None, None
    try:
        import openai
    except ImportError:
        return None, None, None
    model = os.environ.get("OPENAI_MODEL", "deepseek-v4-pro")
    try:
        extra = json.loads(os.environ.get("LLM_EXTRA_BODY", "{}"))
    except Exception:
        extra = {}
    return openai.OpenAI(base_url=base, api_key=key), model, extra


def _llm_json(client, model, extra, prompt, temperature=0.3):
    r = client.chat.completions.create(
        model=model,
        messages=[{"role": "system", "content": WRITER_SYSTEM},
                  {"role": "user", "content": prompt}],
        extra_body=extra, temperature=temperature)
    text = r.choices[0].message.content or ""
    m = re.search(r"```json\s*(.*?)```", text, re.S)
    blob = m.group(1) if m else text
    s, e = blob.find("{"), blob.rfind("}")
    if s >= 0 and e > s:
        blob = blob[s:e + 1]
    try:
        return json.loads(blob)
    except Exception:
        return {}


WRITER_SYSTEM = """你是一位严谨的中文学术论文写作者，只做一件事：基于给定的【真实素材】撰写论文文字。

铁律（违反即不合格）：
1. 只能使用素材中出现的数值、方法名、数据集名、文献、结论。**不得引入任何素材以外的数字、文献、方法或事实**。
2. 不得夸大。若某个命题素材不支持，就明说"证据不足/未获支持"，不得粉饰。
3. 不得写空话套话（如"具有重要意义""被广泛采用""值得进一步研究"），每句话都要承载具体信息（具体数字、具体方法、具体机制）。
4. 用中文书面语，段落连贯，避免罗列式短句堆砌。
5. 严格按要求的 JSON 键输出，不要输出 JSON 以外的任何内容。"""


def _fact_pack(spec, hyp, exp, refs, analysis, best_method, best_value):
    """把真实素材压成一份给 LLM 的事实包。"""
    metrics = exp.get("metrics") or []
    lines = []
    lines.append("## 任务")
    lines.append(f"- 任务类型：{spec.get('task_type','')}")
    lines.append(f"- 数据集：{_dataset_label(spec)}")
    lines.append(f"- 研究主题：{spec.get('title','') or spec.get('topic','')}")
    lines.append(f"- 候选方法：{_join_methods(spec.get('candidate_methods', []))}")
    lines.append(f"- 主指标：{spec.get('metric','')}（{spec.get('objective','')}）")
    lines.append(f"- 研究问题：{spec.get('research_question','') or spec.get('hypothesis_statement','')}")
    for sh in spec.get("sub_hypotheses", []):
        if isinstance(sh, dict):
            lines.append(f"- 子假设 {sh.get('id','')}：{sh.get('statement','')}（预期：{sh.get('expected','')}）")
        else:
            lines.append(f"- 子假设：{sh}")
    if spec.get("analysis_plan"):
        lines.append(f"- 分析计划：{spec['analysis_plan']}")

    lines.append("")
    lines.append("## 真实实验指标（确定性分析引擎计算）")
    for m in metrics:
        lines.append(f"- {m.get('name')} = {_fmt(m.get('value'))}")
    lines.append(f"- 主指标最优：{best_method} = {_fmt(best_value)}")

    # 跨数据集实验：把 cross_table / 排名稳定性 / 逐方法 std/gap 真实数字注入，
    # 否则大模型在“深入分析”里会声称“素材未提供”而拒绝引用真实数值。
    if analysis.get("task_type") == "multi_dataset":
        ct = analysis.get("cross_table") or {}
        order = analysis.get("method_order") or []
        stab = analysis.get("rank_stability") or {}
        lines.append("")
        lines.append("## 跨数据集真实指标（确定性分析引擎计算，必须引用）")
        for lab in (analysis.get("dataset_labels") or []):
            row = ct.get(lab, {})
            cells = [f"{m}={row.get(m):.4f}" for m in order if row.get(m) is not None]
            lines.append(f"- {lab}：{'，'.join(cells)}")
        if stab:
            lines.append("- 排名稳定性（平均排名越小越稳健；标准差越小跨数据集越一致）：" + "；".join(
                f"{m} 均值={s['mean_rank']:.2f} 标准差={s['std_rank']:.2f}" for m, s in stab.items()))
        pstats = analysis.get("per_method_stats") or {}
        if pstats:
            lines.append("- 逐方法多种子标准差 / 训练-测试 gap（按数据集，仅供如实引用）：")
            for m in order:
                entries = pstats.get(m, {})
                bits = []
                for lab, e in entries.items():
                    s = e.get("acc_std")
                    g = e.get("gap")
                    if s is not None:
                        bits.append(f"{lab} std={s:.4f}")
                    if g is not None:
                        bits.append(f"{lab} gap={g:.4f}")
                if bits:
                    lines.append(f"  - {m}：" + "；".join(bits))
        ev = analysis.get("sub_hypothesis_evidence") or {}
        if ev:
            lines.append("- 子假设确定性裁决（分析引擎基于实测数据算出，你的结论必须与之一致，不得矛盾）：")
            for hid in sorted(ev.keys(), key=lambda k: int(re.sub(r"\D", "", k) or 0)):
                e = ev[hid]
                lines.append(f"  - {hid}: 裁决={e.get('verdict', '由你判断')}；依据={e.get('conclusion', '')[:300]}")

    if analysis:
        lines.append("")
        lines.append("## 深入分析结果")
        if analysis.get("seed_variance"):
            lines.append("- 多种子方差：" + json.dumps(analysis["seed_variance"], ensure_ascii=False)[:1500])
        if analysis.get("significance"):
            lines.append(f"- 显著性检验：{analysis['significance']}")
        if analysis.get("per_class"):
            lines.append("- 逐类指标：" + json.dumps(analysis["per_class"], ensure_ascii=False)[:1200])
        if analysis.get("confusion_matrix"):
            lines.append("- 混淆矩阵：" + json.dumps(analysis["confusion_matrix"], ensure_ascii=False)[:900])
        if analysis.get("feature_importance"):
            # 按真实数值降序给出最优方法的 top-K 判别特征。
            # 旧做法是把整个字典 json.dumps 后截断 800 字符喂给模型：顺序被打乱、
            # 还会被截断，导致模型误以为中等权重的特征最重要，写出与 §5.3
            # 特征重要性表矛盾的叙事（例如把 mean 系列说成最高，而真实最高是
            # worst 系列）。这里显式排序并标注「最高的就是这些」，从源头堵住该矛盾。
            fi = analysis["feature_importance"]
            _focus = best_method if isinstance(fi, dict) and best_method in fi else None
            if _focus is None and isinstance(fi, dict) and fi:
                _focus = list(fi.keys())[0]
            if _focus:
                _vals = fi[_focus]
                try:
                    _top = sorted(_vals.items(), key=lambda kv: -abs(kv[1]))[:10]
                except Exception:
                    _top = []
                if _top:
                    lines.append(
                        f"- 特征重要性（以最优方法 {_focus} 为准，按绝对值从高到低排序的前 {len(_top)} 个，"
                        f"这正是 §5.3 特征重要性表所列的顺序）：")
                    lines.append("  " + "；".join(f"{k}={v:.4f}" for k, v in _top))
                    lines.append(
                        "  【重要约束：叙述时只能说上面这些真实排名最高的特征「权重最高/主导」；"
                        "严禁把排名靠后的中等权重特征描述成「具有极高权重」。】")
        sub_ev = analysis.get("sub_hypothesis_evidence") or {}
        if sub_ev:
            lines.append("- 子假设确定性裁决（分析引擎基于实测数据算出，你的结论必须与之一致）：")
            for hid in sorted(sub_ev.keys(), key=lambda k: int(re.sub(r"\D", "", k) or 0)):
                ev = sub_ev[hid]
                lines.append(f"  - {hid}: 裁决={ev.get('verdict','由你判断')}；依据={ev.get('conclusion','')[:200]}")
    lines.append(f"- 实验轮次：{exp.get('best_round')} / 终态：{exp.get('terminal_state')}")
    lines.append(f"- 实验自述发现：{exp.get('findings', [])}")

    if refs:
        lines.append("")
        lines.append("## 真实参考文献（只能引用这些，引用格式用 [编号]）")
        for r in refs:
            lines.append(f"[{r['num']}] {r['authors']}. {r['title']}. {r['venue']}, {r['year']}.")
    return "\n".join(lines)


def llm_write_sections(spec, hyp, exp, refs, analysis, best_method, best_value, review):
    """返回 dict，含 LLM 撰写的各文字段；失败时返回 {}。"""
    client, model, extra = _llm_client()
    if client is None:
        return {}
    facts = _fact_pack(spec, hyp, exp, refs, analysis, best_method, best_value)
    sub_list = spec.get("sub_hypotheses", [])
    sub_str = "\n".join(f"{i+1}. {s}" for i, s in enumerate(sub_list)) or "（无子假设）"

    # 是否多数据集研究：决定「深入分析 / 讨论」该引用跨数据集表还是单数据集表，
    # 避免出现「素材未提供第5.1节跨数据集对比表」这类在单数据集研究中把 §5.1 错标为
    # 跨数据集表、进而显得自相矛盾的虚假表述。
    is_multi = (analysis or {}).get("task_type") == "multi_dataset"
    if is_multi:
        stability_instr = (
            "稳定性与显著性——引用第 5.1 节跨数据集对比表中最优与次优方法在各数据集上的具体差值，"
            "以及排名稳定性表中的平均排名与排名标准差说明跨数据集稳健性；若素材未提供显著性 p 值，"
            "就如实说明“未做跨数据集配对显著性检验”，不要虚构 p 值。"
        )
        multi_note = "本文为多数据集研究，可直接讨论跨数据集排名稳定性与稳健性。"
    else:
        stability_instr = (
            "稳定性与显著性——本实验为【单数据集】研究：引用第 5.1 节主指标对比表中不同方法的具体差值"
            "说明最优方法的相对优势；用多种子标准差（seed variance）说明方法在该数据集上的稳定性；"
            "明确指出本文仅基于单一数据集，跨数据集稳健性留待后续多数据集研究，"
            "【严禁声称存在“第 5.1 节跨数据集对比表”或“排名稳定性表”（它们在本研究中不存在）】，"
            "也不要说“素材未提供”这类把单数据集 §5.1 错标为跨数据集表的措辞；若素材未提供显著性 p 值，"
            "就如实说明“未做配对显著性检验”，不要虚构 p 值。"
        )
        multi_note = "本文为单数据集研究：讨论聚焦本数据集内的结论与边界，不得引用不存在的跨数据集表。"

    out = {}

    # 第一批：摘要 + 引言 + 相关工作
    p1 = f"""{facts}

请基于以上真实素材撰写论文前三部分，输出 JSON：
{{"abstract": "250-350 字摘要：背景与缺口、本文做什么、关键数字、结论",
  "keywords": "5-7 个中文关键词，用；分隔",
  "intro": "引言 3 段：第1段该方向的实际重要性与现有研究的缺口（引用文献 [编号]）；第2段本文具体要回答的机理问题；第3段本文贡献（编号列出3-4条，都要有具体数字或具体动作）",
  "related": "相关工作 2-3 段：按主题（不是逐篇罗列）综述上述文献，说明它们各自的立场与局限，并指出本文与它们的关系与差异。必须出现 [编号] 引用。"}}"""
    r1 = _llm_json(client, model, extra, p1)
    out.update({k: v for k, v in r1.items() if isinstance(v, str) and v.strip()})

    # 第二批：结果叙述 + 深入分析 + 子假设裁决
    p2 = f"""{facts}

请基于以上真实素材撰写结果分析部分，输出 JSON：
{{"results_narrative": "2 段：客观叙述表 1 与图的结果，指认最优方法与次优方法的具体数值差，不夸大",
  "deep_analysis": "深入分析 3 段（本文最重要的一节）：(1) 为什么最优方法会赢——从机理上解释（模型的归纳偏置、正则化、距离度量、特征降维等如何与该数据特性相互作用），必须落到具体数字，并引用第 5.1 节对比表中最优与次优方法的具体差值（如某数据集上 A=0.97、B=0.95，差 0.02）；
  若素材给出了「特征重要性（按绝对值从高到低排序）」，必须严格以该排序为准叙述真正权重最高的特征，
  严禁把排名靠后的中等权重特征说成「具有极高权重」「主导决策边界」，也严禁编造素材中不存在的特征名或数值，
  以免与第 5.3 节特征重要性表自相矛盾；(2) 它在哪里失败——若能引用逐类指标 / 混淆矩阵中表现最差的具体类别名称及其数值就引用并指出错误系统性来源；若素材未提供逐类指标或混淆矩阵，就如实说明“本实验未采集逐类明细”，不要编造；(3) {stability_instr}",
  "sub_verdicts": [{{"statement": "子假设原文", "verdict": "支持/部分支持/不支持/证据不足 之一", "evidence": "一句话，只引用素材中的具体数字"}}]}}

子假设清单：
{sub_str}"""
    r2 = _llm_json(client, model, extra, p2)
    out.update({k: v for k, v in r2.items() if v})

    # 第三批：讨论 + 结论 + 局限性补充
    unsupported = (review or {}).get("unsupported_claims") or []
    ev = exp.get("sub_hypothesis_evidence") or {}
    ev_str = "\n".join(f"{hid}: 裁决={e.get('verdict','')} — {e.get('conclusion','')[:200]}"
                      for hid, e in ev.items()) if ev else "（无，本文未生成子假设证据）"
    p3 = f"""{facts}

评审意见中指出的问题：{unsupported if unsupported else '（无）'}

子假设已裁定结果（讨论与结论必须与之完全一致，不得矛盾、不得反向编造）：
{ev_str}

研究范围提醒：{multi_note}

请基于以上真实素材撰写收尾部分，输出 JSON：
{{"discussion": "讨论 2 段：(1) 本文发现与前述文献如何呼应或冲突（带 [编号] 引用），以及本文发现在实践上的具体含义（给方法选型的具体建议，而不是泛泛而谈）；(2) 本文结论成立的条件与边界——在什么数据规模/特征结构/噪声条件下结论可能不成立。讨论中提到的假设结论必须与上面“子假设已裁定结果”一致。",
  "conclusion": "（本段由系统确定性生成，无需你写；直接输出空字符串即可）",
  "limitations_extra": "1-3 条本文特有的局限性（基于素材中的真实不足，不要写放之四海皆准的套话）"}}"""
    r3 = _llm_json(client, model, extra, p3)
    out.update({k: v for k, v in r3.items() if isinstance(v, str) and v.strip()})

    return out


# ── 降级骨架（LLM 不可用时使用，避免废话但仍远好于旧版） ─────────────
def _fallback_sections(spec, exp, refs, best_method, best_value, main_metric):
    ds = _dataset_label(spec)
    claim = "具体假设是否成立，应以对应指标与证据字段为准。"
    return {
        "abstract": (
            f"本文在 {ds} 数据集上围绕「{spec.get('research_question','')}」展开实证研究，"
            f"系统比较了 {_join_methods(spec.get('candidate_methods',[]))} 等方法的表现。"
            f"确定性分析引擎依据任务规格执行实验，主指标 {main_metric} 的最优结果为 "
            f"{best_method} 的 {_fmt(best_value)}。{claim}"
        ),
        "keywords": "；".join(filter(None, [spec.get("topic", ""), ds,
                                            _join_methods(spec.get("candidate_methods", [])[:2]),
                                            main_metric])),
        "intro": (
            f"{spec.get('direction','')} 的方法选型长期依赖经验而非受控对比。"
            f"本文聚焦的具体机理问题是：{spec.get('research_question','')}。"
            f"为此在 {ds} 上统一预处理与评估协议，比较 {_join_methods(spec.get('candidate_methods',[]))}，"
            f"并以 {main_metric} 为主指标给出可复现结论。"
        ),
        "related": "；".join(
            f"[{r['num']}] {r['title']}（{r['venue']}, {r['year']}）" for r in refs[:8]
        ) + "。上述工作分别为本文的方法选择与实验设计提供了参照。",
        "results_narrative": f"表 1 汇总了全部实验指标，最优方法为 {best_method}，主指标 {main_metric} = {_fmt(best_value)}。",
        "deep_analysis": "（大模型写作不可用，深入分析节省略；请以第 5 节的真实表格与图为准。）",
        "sub_verdicts": [],
        "discussion": f"结果显示 {best_method} 在本任务设定下占优，但该结论受 {ds} 的样本规模与特征结构约束。",
        "conclusion": f"本文在 {ds} 上得到主指标 {main_metric} 最优结果 {best_method}（{_fmt(best_value)}）；该结果本身不等同于主假设已获验证。",
        "limitations_extra": "",
    }


def _deterministic_conclusion(spec: dict, analysis: dict, sub_evidence: dict, is_multi: bool) -> str:
    """结论始终由证据表 + 真实数字确定性生成，绝不依赖大模型自由发挥，
    因此不可能与第 6 节裁决表矛盾（彻底杜绝“结论支持 / 裁决证据不足”这类虚假错误）。"""
    metric = spec.get("metric") or "accuracy"
    bits = []
    for hid in sorted(sub_evidence.keys(), key=lambda k: int(re.sub(r"\D", "", k) or 0)):
        e = sub_evidence[hid]
        v = e.get("verdict") or "证据不足"
        concl = (e.get("conclusion") or "").strip()
        bits.append(f"{hid}（{v}）：{concl}")
    if is_multi:
        stab = analysis.get("rank_stability") or {}
        best = min(stab.items(), key=lambda kv: kv[1].get("mean_rank", 99))[0] if stab else None
        lead = (f"综合三个数据集，{best} 的平均排名最低（{stab[best]['mean_rank']:.2f}）、"
                f"跨数据集最稳健" if best else "综合跨数据集表现")
    else:
        best = analysis.get("best_method")
        bv = analysis.get("best_value")
        lead = (f"在单数据集上主指标 {metric} 最优为 {best}（{_fmt(bv)}）" if best else "在单数据集上")
    body = "；".join(bits) if bits else "（未生成子假设证据）"
    return (f"本文基于确定性实验证据给出如下结论。{lead}。"
            f"各子假设裁决如下：{body}。"
            f"凡未被证据支持的假设，文中均已如实标注为证据不足，未做粉饰。")


# ── Markdown → docx ───────────────────────────────────────────────
def md_to_docx(md: str, out_path: Path, media_root: Path):
    from docx import Document
    from docx.shared import Pt, Inches
    doc = Document()
    lines = md.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue
        # 图片
        mimg = re.match(r"!\[(.*?)\]\((.*?)\)", line.strip())
        if mimg:
            p = media_root / mimg.group(2)
            if p.exists():
                try:
                    doc.add_picture(str(p), width=Inches(5.6))
                    cap = doc.add_paragraph(mimg.group(1))
                    cap.runs[0].italic = True
                    cap.alignment = 1
                except Exception:
                    doc.add_paragraph(f"[图片：{mimg.group(1)}]")
            i += 1
            continue
        # 表格
        if line.strip().startswith("|"):
            block = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                block.append(lines[i].strip())
                i += 1
            rows = []
            for r in block:
                cells = [c.strip() for c in r.strip("|").split("|")]
                rows.append(cells)
            rows = [r for r in rows if not all(set(c) <= set("-: ") for c in r)]
            if rows:
                ncol = max(len(r) for r in rows)
                tbl = doc.add_table(rows=0, cols=ncol)
                tbl.style = "Table Grid"
                for ri, r in enumerate(rows):
                    cells = r + [""] * (ncol - len(r))
                    rowc = tbl.add_row().cells
                    for ci, c in enumerate(cells):
                        rowc[ci].text = c
                        for para in rowc[ci].paragraphs:
                            for run in para.runs:
                                run.font.size = Pt(9)
                                run.bold = (ri == 0)
            doc.add_paragraph("")
            continue
        # 标题
        if line.startswith("# "):
            doc.add_heading(line[2:], level=0)
        elif line.startswith("## "):
            doc.add_heading(line[3:], level=1)
        elif line.startswith("### "):
            doc.add_heading(line[4:], level=2)
        else:
            txt = line
            if txt.startswith("**") and txt.endswith("**") and txt.count("**") == 2:
                p = doc.add_paragraph()
                p.add_run(txt.replace("**", "")).bold = True
            elif txt.startswith("- "):
                doc.add_paragraph(txt[2:], style="List Bullet")
            elif re.match(r"^\d+\.\s", txt):
                doc.add_paragraph(re.sub(r"^\d+\.\s", "", txt), style="List Number")
            else:
                doc.add_paragraph(txt)
        i += 1
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))


# ── 主流程 ────────────────────────────────────────────────────────
def main() -> int:
    ap = argparse.ArgumentParser(description="从流水线真实产物生成完整中文论文（任务无关）")
    ap.add_argument("--output-dir", default="out_v2")
    ap.add_argument("--task-spec", default="")
    args = ap.parse_args()

    base = Path(args.output_dir).resolve()
    lit = _load(base / "01_literature.json")
    hyp = _load(base / "02_hypotheses.json")
    exp = _load(base / "03_experiment.json")
    review = _load(base / "04_review.json") if (base / "04_review.json").exists() else {}

    spec: dict = {}
    if args.task_spec and Path(args.task_spec).exists():
        try:
            spec = json.loads(Path(args.task_spec).read_text(encoding="utf-8"))
        except Exception:
            spec = {}
    elif (base / "task_spec.json").exists():
        try:
            spec = json.loads((base / "task_spec.json").read_text(encoding="utf-8"))
        except Exception:
            spec = {}

    metrics = exp.get("metrics") or []
    analysis = exp.get("analysis") or exp
    is_multi = (analysis or {}).get("task_type") == "multi_dataset"
    main_metric = spec.get("metric") or ""
    objective = spec.get("objective") or "maximize"
    dataset = "多数据集" if is_multi else _dataset_label(spec)
    direction = {"classification": "分类任务", "regression": "回归任务"}.get(
        spec.get("task_type"), spec.get("direction") or spec.get("topic") or "机器学习任务")
    methods = _join_methods(spec.get("candidate_methods", [])) or "若干基线模型"

    best_method, best_value = _best_method(metrics, main_metric, objective)
    if is_multi:
        # 跨数据集最稳健的赢家 = 平均排名最低的方法
        stab = (analysis or {}).get("rank_stability") or {}
        if stab:
            best_method = min(stab.items(), key=lambda kv: kv[1].get("mean_rank", 99))[0]
        best_value = None
        best_value_str = "见跨数据集对比表"
    else:
        best_value_str = _fmt(best_value) if best_value is not None else "见指标表"

    refs = build_references(lit)
    ref_lines = []
    for r in refs:
        line = f"[{r['num']}] {r['authors']}. {r['title']}"
        if r["venue"]:
            line += f"[J]. {r['venue']}"
        if r["year"]:
            line += f", {r['year']}"
        if r["url"]:
            line += f". {r['url']}"
        ref_lines.append(line + ".")
    references_block = "\n".join(ref_lines)

    # LLM 撰写文字
    written = llm_write_sections(spec, hyp, exp, refs, analysis, best_method, best_value, review)
    used_llm = bool(written.get("abstract"))
    if not written.get("abstract"):
        written = _fallback_sections(spec, exp, refs, best_method, best_value, main_metric)

    # ── 引入子假设证据字段（若存在） ──────────────────────────────
    sub_evidence = (analysis or {}).get("sub_hypothesis_evidence") or {}

    # 子假设裁决表（优先用确定性分析引擎产出的证据，再降级到 LLM 写作）
    sub_rows = []
    sub_specs = spec.get("sub_hypotheses") or []
    if sub_evidence:
        # evidence 键为 H1..H4，与 spec.sub_hypotheses 同序
        for i, sh in enumerate(sub_specs):
            hid = f"H{i+1}"
            ev = sub_evidence.get(hid)
            if not ev:
                sub_rows.append([hid, "待验证", str(sh.get("statement", "") if isinstance(sh, dict) else sh)[:80]])
                continue
            concl = ev.get("conclusion", "") or ""
            # 引擎已给出确定性裁决时直接采用（与方法比较证据保持一致）
            # 关键：引擎未给出裁决时，绝不根据结论文本关键词“反推/编造”裁决，
            # 否则会出现“裁决表=部分支持 / 结论=证据不足”的虚假矛盾。
            # 一律回退为“证据不足”，与 _deterministic_conclusion 的结论段永久一致。
            engine_verdict = ev.get("verdict")
            if engine_verdict:
                verdict = engine_verdict
            else:
                verdict = "证据不足"
            sub_rows.append([f"{hid} {str(sh.get('statement', '') if isinstance(sh, dict) else sh)[:48]}", verdict, concl[:140]])
    elif written.get("sub_verdicts"):
        for v in written["sub_verdicts"]:
            if isinstance(v, dict):
                sub_rows.append([str(v.get("statement", ""))[:60],
                                 str(v.get("verdict", "")),
                                 str(v.get("evidence", ""))[:140]])
    if not sub_rows and sub_specs:
        for i, s in enumerate(sub_specs):
            stmt = s.get("statement") if isinstance(s, dict) else str(s)
            sub_rows.append([f"H{i+1} {str(stmt)[:48]}", "待验证", ""])
    sub_table = _md_table(["子假设", "裁决", "依据"], sub_rows) if sub_rows else ""

    # 图表块
    per_class_tbl = _per_class_table(analysis, prefer=(best_method or ""))
    conf_tbl = _confusion_table(analysis, prefer=(best_method or ""))
    fi_tbl = _feature_importance_table(analysis)
    plots_md = _plots_block(analysis, base)

    # 局限性
    ds_scope = "多个数据集" if is_multi else f"{dataset}数据集"
    lim = [f"实验基于{ds_scope}，样本规模与特征结构有限，结论向更大规模或不同分布数据的外推仍需验证。"]
    if (analysis or {}).get("seed_variance"):
        lim.append("多种子实验虽已报告均值±标准差并做显著性检验，但种子数有限（5 个），方差估计本身仍不够精确。")
    else:
        lim.append("未提供多次运行的方差或显著性检验，指标差异的统计稳健性尚待评估。")
    lim.append("实验由确定性分析引擎在本地进程直接执行候选方法（sklearn 生态），未接入 GPU 加速，候选方法规模与超参数搜索空间有限。")
    if (written.get("limitations_extra") or "").strip():
        # LLM 常把多条局限性塞进同一个字符串并自带编号（形如
        # "…结论的外推性受限。2. 多种子分析…。3. 未进行超参数调优…"）。
        # 旧实现只用 re.sub 剥掉「开头第一个」编号，内部残留的 "2." "3."
        # 会连同正文一起成为第 4 条，最终渲染出 1,2,3,4,2,3 的错乱编号。
        # 这里改为：先按换行拆分，再按「数字.」边界切分，逐条去编号后各自独立成条。
        _raw = written["limitations_extra"].strip()
        _segs = []
        for _part in re.split(r"[ \t]*\n+", _raw):
            _part = _part.strip()
            if not _part:
                continue
            for _s in re.split(r"(?<!\d)\s*(?=\d{1,2}\.\s)", _part):
                _s = re.sub(r"^\s*\d{1,2}\.\s*", "", _s).strip()
                if _s:
                    _segs.append(_s)
        if not _segs:
            _segs = [re.sub(r"^\s*\d{1,2}\.\s*", "", _raw).strip()]
        for _s in _segs:
            lim.append(_s)
    if (review or {}).get("unsupported_claims"):
        lim.append("正如同行评审所指出的，当前证据链仍有待加强，需要在后续工作中补强。")
    limitations_block = "\n".join(f"{i+1}. {t}" for i, t in enumerate(lim))

    if is_multi:
        title = f"{direction}：跨数据集泛化性对比的机理实证研究"
    else:
        title = f"{direction}：基于 {dataset} 数据集的机理实证研究"

    parts = []
    parts.append(f"# {title}\n")
    parts.append("## 摘要\n")
    parts.append(written.get("abstract", "").strip() + "\n")
    parts.append(f"**关键词：** {written.get('keywords','')}\n")
    parts.append("## 1 引言\n")
    parts.append(written.get("intro", "").strip() + "\n")
    parts.append("## 2 相关工作\n")
    parts.append(written.get("related", "").strip() + "\n")

    parts.append("## 3 方法\n")
    parts.append(f"### 3.1 问题设定\n")
    if is_multi:
        parts.append(f"本文在多个数据集上研究{direction}。研究问题为：{spec.get('research_question','')}\n")
    else:
        parts.append(f"本文在 {dataset} 数据集上研究{direction}。研究问题为：{spec.get('research_question','')}\n")
    parts.append("### 3.2 候选方法\n")
    mb = _method_bullets(spec)
    if mb:
        parts.append("本文比较的候选方法覆盖了不同的归纳偏置与建模思路：\n")
        parts.append(mb + "\n")
    else:
        parts.append(f"本文比较的候选方法包括：{methods}，覆盖了该任务上典型的方法选择空间。\n")
    parts.append("### 3.3 评价协议\n")
    # 次要指标：优先采用 spec 声明；未声明时退回到实验数据里真实测过的指标
    # （典型如 f1_macro），避免出现「次要指标为 —」这种占位符残留。
    _sec = [s for s in (spec.get("secondary_metrics") or []) if s]
    if not _sec:
        _sv = (analysis or {}).get("seed_variance") or {}
        _seen = []
        for _k in _sv.keys():
            if "_" in _k:
                _mn = _k.split("_", 1)[1]
                if _mn != main_metric and _mn not in _seen:
                    _seen.append(_mn)
        _sec = _seen[:2]
    if _sec:
        _sec_txt = "、".join(_sec) + "（详见第 5.4 节）"
    else:
        _sec_txt = "本文未设置独立次要指标，一切结论均以主指标为准"
    parts.append(f"主要评价指标为 {main_metric}（{'越大越好' if objective=='maximize' else '越小越好'}），"
                 f"次要指标为 {_sec_txt}。"
                 f"所有实验在 5 个随机种子（42–46）上重复，报告均值±标准差，并对最优与次优方法做配对显著性检验。\n")
    parts.append("### 3.4 研究假设\n")
    main_hyp = spec.get("hypothesis_statement") or spec.get("research_question") or ""
    if main_hyp:
        parts.append(f"主假设：{main_hyp}\n")
    if spec.get("sub_hypotheses"):
        parts.append("待检验的机制化子假设见第 6 节表 2 的裁决。\n")

    parts.append("## 4 实验设置\n")
    if is_multi:
        round_txt = "各数据集均取主指标最优的一轮作为报告结果。"
    else:
        round_txt = f"最终取主指标最优的一轮（第 {exp.get('best_round')} 轮）作为报告结果。"
    _pp = (analysis or {}).get("preprocessing")
    if _pp and _pp.get("columns"):
        _rows = [[c["name"], c["kind"], str(c["missing"]), c["encoding"]]
                 for c in _pp["columns"]]
        parts.append(f"实验数据为{dataset}，共 {_pp.get('n_samples')} 个样本、"
                     f"{_pp.get('n_raw_features')} 个原始特征，缺失值合计 {_pp.get('n_missing_total')} 个。"
                     f"各特征列的推断类型与预处理方式如下：\n")
        parts.append("**表 特征列预处理明细**\n")
        parts.append(_md_table(["特征列", "推断类型", "缺失量", "预处理方式"], _rows) + "\n")
        parts.append("缺失值插补与标准化所需的统计量（中位数、众数、均值与方差）"
                     "均在训练折上拟合后再作用于测试折，避免信息从测试集泄漏到训练过程；"
                     "字符串类别列先做众数插补再独热展开，基数过大（超过 20 个取值）的列"
                     "降级为序数编码以控制维度。实验由确定性分析引擎依据任务规格直接执行候选方法，"
                     f"{round_txt}\n")
    else:
        _pp_multi = (analysis or {}).get("preprocessing_by_dataset") or {}
        if _pp_multi:
            rows, trivial_ds = [], []
            for ds_label, pp in _pp_multi.items():
                cols = pp.get("columns") or []
                # 只披露「非平凡」列：数值列仅做标准化，逐列列出没有信息量
                non_trivial = [c for c in cols
                               if c.get("missing", 0) > 0 or c.get("kind") != "数值"]
                if not non_trivial:
                    trivial_ds.append(ds_label)
                    continue
                for c in non_trivial:
                    rows.append([ds_label, c["name"], c["kind"],
                                 str(c["missing"]), c["encoding"]])
            parts.append(f"实验数据为 {len(_pp_multi)} 个数据集。"
                         f"各数据集逐列的预处理方式如下。\n")
            if rows:
                parts.append("**表 各数据集非平凡预处理明细**\n")
                parts.append(_md_table(["数据集", "特征列", "推断类型", "缺失量", "预处理方式"], rows) + "\n")
            if trivial_ds:
                parts.append(f"其中 {'、'.join(trivial_ds)} 为全数值且无缺失值，仅做标准化处理。\n")
            parts.append("缺失值插补与标准化所需的统计量（中位数、众数、均值与方差）"
                         "均在训练折上拟合后再作用于测试折，避免信息从测试集泄漏到训练过程；"
                         "字符串类别列先做众数插补再独热展开，基数过大（超过 20 个取值）的列"
                         "降级为序数编码以控制维度。实验由确定性分析引擎依据任务规格直接执行候选方法，"
                         f"{round_txt}\n")
        else:
            parts.append(f"实验数据为{'多个数据集' if is_multi else dataset}。"
                         f"数据经标准化等必要预处理后按固定比例划分训练集与测试集。"
                         f"实验由确定性分析引擎依据任务规格直接执行候选方法，{round_txt}\n")

    parts.append("## 5 实验结果\n")
    if is_multi:
        parts.append("### 5.1 跨数据集泛化性对比\n")
        parts.append(_cross_dataset_block(analysis, base) + "\n")
        parts.append("各数据集上逐方法的完整指标、多种子方差与可视化图表见本目录下的 "
                     "`results/<数据集名>/03_experiment.json` 及对应图片。\n")
    else:
        parts.append("### 5.1 主指标对比\n")
        parts.append("**表 1 各方法主指标对比**\n")
        parts.append(_main_metric_table(metrics, main_metric, objective) + "\n")
        parts.append(written.get("results_narrative", "").strip() + "\n")
        if plots_md.strip():
            parts.append("### 5.2 结果可视化\n")
            parts.append(plots_md + "\n")
        if per_class_tbl or conf_tbl or fi_tbl:
            parts.append("### 5.3 细粒度分析\n")
            for blk in (per_class_tbl, conf_tbl, fi_tbl):
                if blk:
                    parts.append(blk + "\n")
        parts.append("### 5.4 稳定性与显著性\n")
        parts.append(_variance_table(analysis) + "\n")
        if (analysis or {}).get("significance"):
            parts.append(f"显著性检验结论：{analysis['significance']}\n")

        # 训练-测试过拟合 Gap（H1 直接证据）
        h1 = sub_evidence.get("H1_overfitting_gap") if sub_evidence else None
        if h1:
            gap_items = h1.get("per_method") or []
            if gap_items:
                gap_rows = [[g["method"], f"{g['train_test_gap']:.4f}"] for g in gap_items]
                parts.append("### 5.5 训练-测试过拟合分析\n")
                parts.append(_md_table(["方法", "训练-测试准确率 gap"], gap_rows) + "\n")
                parts.append(f"线性模型平均 gap = {h1.get('linear_mean_gap','?'):.4f}，"
                             f"集成模型平均 gap = {h1.get('ensemble_mean_gap','?'):.4f}。"
                             f"结论：{h1.get('conclusion','')}。\n")

    parts.append("## 6 深入分析\n")
    parts.append(written.get("deep_analysis", "").strip() + "\n")
    if sub_rows:
        parts.append("**表 2 子假设裁决**\n")
        parts.append(sub_table + "\n")
    elif spec.get("sub_hypotheses"):
        parts.append("待检验的子假设：\n")
        parts.append(sub_table + "\n")

    parts.append("## 7 讨论\n")
    parts.append(written.get("discussion", "").strip() + "\n")

    # 结论：始终由证据表 + 真实数字确定性生成，禁止与第 6 节裁决表矛盾
    if sub_evidence:
        conclusion_text = _deterministic_conclusion(spec, analysis, sub_evidence, is_multi)
    else:
        conclusion_text = (written.get("conclusion", "") or "").strip()

    parts.append("## 8 结论\n")
    parts.append(conclusion_text + "\n")

    parts.append("## 局限性\n")
    parts.append(limitations_block + "\n")

    parts.append("## 附录：完整指标表\n")
    if metrics:
        parts.append(_full_metrics_table(metrics) + "\n")
    elif is_multi:
        _ap_rows = []
        for lab in (analysis.get("dataset_labels") or []):
            row = (analysis.get("cross_table") or {}).get(lab, {})
            cells = [f"{row.get(m):.4f}" if row.get(m) is not None else "—"
                     for m in (analysis.get("method_order") or [])]
            _ap_rows.append([lab] + cells)
        if _ap_rows:
            parts.append(_md_table(["数据集"] + (analysis.get("method_order") or []), _ap_rows) + "\n")
            parts.append("（跨数据集各方法主指标；逐数据集完整指标见 `results/<数据集名>/03_experiment.json`）\n")
        else:
            parts.append("（无数据）\n")
    else:
        parts.append("（无数据）\n")

    parts.append("## 参考文献\n")
    parts.append(references_block + "\n")

    paper = "\n".join(parts)

    out_md = base / "06_paper" / "paper_full.md"
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text(paper, encoding="utf-8")

    docx_note = ""
    out_docx = base / "06_paper" / "paper_full.docx"
    try:
        md_to_docx(paper, out_docx, base)
        docx_note = f"；已生成 Word 文档：{out_docx}"
    except ImportError:
        docx_note = "（未安装 python-docx，仅输出 Markdown）"
    except Exception as e:
        docx_note = f"；Word 生成失败：{e}"

    print(json.dumps({
        "status": "ok",
        "markdown": str(out_md),
        "llm_written": bool(used_llm and written.get("abstract")) and "deep_analysis" in written,
        "references_count": len(refs),
        "metrics_count": len(metrics),
        "best_method": best_method,
        "best_value": best_value,
        "plots_count": len(analysis.get("plots") or []),
        "note": docx_note,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
